"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeBox = function (x) { return ([x]); };
exports.unbox = function (b) { return b[0]; };
exports.setBox = function (b, v) { b[0] = v; return; };
//# sourceMappingURL=box.js.map